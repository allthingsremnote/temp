chrome.runtime.onMessage.addListener(
    function (request, sender, sendResponse) {
        if (request.msg == "sync") {

            chrome.tabs.create({ url: "https://read.amazon.com/notebook" }, function (tab) {
                chrome.tabs.onUpdated.addListener(function listener(tabId, info) {
                    if (info.status === 'complete' && tabId === tab.id) {
                        chrome.tabs.onUpdated.removeListener(listener);
                        console.log(info, tab)
                        chrome.tabs.executeScript(tab.id, {
                            file: 'kindleNotes.js'
                        });
                    }
                });
            });
        }
        if (request.msg == "syncFinished") {
            chrome.notifications.create(Math.random().toString(), {
                type: 'basic',
                title: 'Hooray!',
                message: 'Your Kindle notes have been synced to RemNote!',
                priority: 1,
                iconUrl: chrome.extension.getURL('book.png')

            }, function (id) { });
        }
    });
chrome.runtime.onInstalled.addListener(function (e) {
    console.log(e);
    if (e.reason == "install") {
        chrome.storage.local.set({ extensionAuthId: Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15) });
    }
});