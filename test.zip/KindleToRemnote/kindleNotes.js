var REMNOTE_URL = "https://remnote-staging.herokuapp.com/"
var userId;
var apiKey;
var loader;
var canvas;
var ctx;
function setVisuals() {

    loader = document.createElement("div");
    loader.innerHTML = `<div style="width: 300px; transition: opacity 0.3s ease 0s; opacity: 1; height: 200px; border-radius: 10px; box-shadow: rgba(128, 128, 128, 0.65) 0px 0px 25px; position: fixed; left: 50%; top: 50%; transform: translate(-50%, -50%); background: rgb(72, 199, 226); color: white; font-weight: bold; z-index: 1000;"><b style="
        position: absolute;
        left: 50%;
        top: 15px;
        transform: translateX(-50%);
        font-size: 30px;
        user-select:none;
        ">Syncing...</b><div style="width: 100px; height: 100px; left: calc(50% - 50px); bottom: 20px; position: absolute; border-width: 1em; border-style: solid; border-image: initial; filter: drop-shadow(gray 0px 0px 2px); border-color: white transparent transparent; transform: rotate(84600deg); border-radius: 100px; transition: transform 1s ease 0s;"></div><b style="position: absolute;left: 50%;top: 46px;transform: translateX(-50%);font-size: 15px;user-select:none;color: #ffffff78;width:100%;text-align:center;" id="syncerStatusText">Abc</b></div>    `
    document.body.appendChild(loader);
    loader.style.zIndex = "1000";
    loader.children[0].children[1].style.transform = `rotate(${Number(loader.children[0].children[1].style.transform.replace("rotate(", "").replace("deg)", "")) + 360}deg)`
    setInterval(function () {
        loader.children[0].children[1].style.transform = `rotate(${Number(loader.children[0].children[1].style.transform.replace("rotate(", "").replace("deg)", "")) + 360}deg)`
    }, 1000);
    setTimeout(function () {
        loader.children[0].children[1].style.transform = `rotate(${Number(loader.children[0].children[1].style.transform.replace("rotate(", "").replace("deg)", "")) + 360}deg)`
        canvas.style.opacity = ".8";
        loader.style.opacity = "1";
        loader.children[0].style.opacity = "1";
    }, 1);
    canvas = document.createElement("canvas");
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    canvas.style.position = "absolute";
    canvas.style.left = "0px";
    canvas.style.top = "0px";
    canvas.style.background = "#ffffff94";
    canvas.style.opacity = "0";
    canvas.style.transition = "opacity .4s";
    document.body.appendChild(canvas);

    document.body.style.overflow = "hidden"
    ctx = canvas.getContext("2d");
    ctx.shadowColor = '#d3d3d3';
    ctx.shadowBlur = 5;
    ctx.globalAlpha = .8;
}
setVisuals();
function checkCredentials() {
    updateStatus("Checking credentials");
    chrome.storage.local.get(["userId"], async function (userIdResult) {
        chrome.storage.local.get(["apiKey"], async function (apiKeyResult) {
            userId = userIdResult.userId;
            apiKey = apiKeyResult.apiKey;

            var credentialCheck = await fetch("https://api.remnote.io/api/v0/get", {
                headers: new Headers({
                    'Content-Type': 'application/json',
                    "x-auth-token": apiKey
                }),
                method: 'POST',
                body: JSON.stringify({
                    remId: "ImpossibleId",
                    userId: userId
                })
            });
            try {
                await credentialCheck.json();
            } catch { }

            if (credentialCheck.status != 200) {
                var updateCredentialsFrame = document.createElement("iframe");
                updateCredentialsFrame.classList.add("updateCredentialsFrame")
                updateCredentialsFrame.src = REMNOTE_URL;
                document.body.appendChild(updateCredentialsFrame);
            } else {

                //Remove all RemNote frames (Created by getting new auth) so the user isnt prompted to save work before leaving
                [...document.getElementsByClassName("updateCredentialsFrame")].forEach(function (x) {
                    x.remove();
                })

                updateStatus("Credentials confirmed");
                beginSync();
            }
        });
    });
}
checkCredentials();
function beginSync() {
    var addCount = 1;
    var circles = [];
    var orbColors = ["#3278bc", "#3949ab", "#1565c0", "#3f51b5"];
    function tick() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        addCount--;
        if (addCount == 0) {
            for (var i = 0; i < Math.floor(Math.random() * 10) + 7; i++) {
                addCircle();
            }
            addCount = Math.floor(Math.random() * 5 + 25);
        }
        for (var i = circles.length; i--;) {
            var circle = circles[i];
            if (circle.x - circle.rad > window.innerWidth || circle.x + circle.rad < 0 || circle.y - circle.rad > window.innerHeight || circle.y + circle.rad < 0) {
                circles.splice(i, 1);
            } else {
                circle.x += circle.xVel;
                circle.y += circle.yVel;
                circle.xVel += circle.xVelChange;
                circle.yVel += circle.yVelChange;

                ctx.fillStyle = circle.color;
                ctx.beginPath();
                ctx.arc(circle.x, circle.y, circle.rad, 0, 2 * Math.PI);
                ctx.shadowBlur = 10;
                ctx.shadowColor = 'black';
                ctx.globalAlpha = (circle.background ? .3 : .8);
                ctx.shadowColor = '#d3d3d3';
                ctx.fill();
            }
            delete circle;
        }

        window.requestAnimationFrame(tick);
    }
    window.onresize = function () {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
    }
    window.requestAnimationFrame(tick);
    var circlesToMake = [];
    var circleMaxSpeed = 5;
    function addCircle(background) {
        if (circlesToMake[0] || background) {
            var circle = {};
            circle.rad = Math.random() * 15 + (background ? 5 : 30);
            circle.background = background;
            circle.color = orbColors[Math.floor(Math.random() * orbColors.length)];
            circle.xVelChange = Math.random() / 5 - 1 / 10;
            circle.yVelChange = Math.random() / 5 - 1 / 10;

            if (Math.random() > .5) {
                addCircle(true);
                //Make background circle
            }
            if (Math.random() > .5) {
                if (Math.random() > .5) {
                    circle.x = -(circle.rad) - 1;
                    circle.y = Math.random() * window.innerHeight;
                    circle.yVel = Math.random() * circleMaxSpeed + 1;
                    circle.xVel = Math.random() * circleMaxSpeed + 1;
                } else {
                    circle.x = window.innerWidth + circle.rad;
                    circle.y = Math.random() * window.innerHeight;
                    circle.yVel = Math.random() * circleMaxSpeed + 1;
                    circle.xVel = Math.random() * -circleMaxSpeed - 1;
                }
            } else {
                if (Math.random() > .5) {
                    circle.x = Math.random() * window.innerHeight;
                    circle.y = -(circle.rad) - 1;
                    circle.yVel = Math.random() * circleMaxSpeed + 1;
                    circle.xVel = Math.random() * circleMaxSpeed + 1;
                } else {
                    circle.x = Math.random() * window.innerHeight;
                    circle.y = window.innerHeight + circle.rad;
                    circle.yVel = Math.random() * -circleMaxSpeed - 1;
                    circle.xVel = Math.random() * circleMaxSpeed + 1;
                }
            }
            circles.push(circle);
            circlesToMake = circlesToMake.slice(1);
        }
    }
    async function loadNotes() {
        var allNotes = [];
        var addedCount = 0;
        // for (j of [...document.getElementsByClassName("kp-notebook-library-each-book")]) {
        [...document.getElementsByClassName("kp-notebook-library-each-book")].forEach(async function (j) {
            var temp = document.createElement("div");
            document.body.appendChild(temp);
            updateStatus(`Gathering books (${addedCount + 1}/${[...document.getElementsByClassName("kp-notebook-library-each-book")].length})`);

            var bookPage = await fetch(`https://read.amazon.com/notebook?asin=${j.id}&contentLimitState=&`);
            temp.innerHTML = await bookPage.text();
            var notes = [...temp.children[0].children[1].children[0].children[0].children[2].children].slice(2);
            notes.pop();
            notes = notes.map(function (x) {
                circlesToMake.push(1);
                return {
                    text: x.children[0].children[1].children[0].children[0].innerText,
                    page: `Page ${x.children[0].children[0].children[1].children[0].innerText.split("|")[1].slice(1).split(":")[1].trim()}`,
                    note: x.children[0].children[1].children[0].children[1].children[1].innerText,
                    color: x.children[0].children[0].children[1].children[0].innerText.split("|")[0].split(" ")[0],
                    bookTitle: j.children[0].children[0].children[1].innerText,
                    asin: j.id
                }

            });
            notes = notes.sort(function (a, b) {
                return a.page - b.page
            });
            addedCount++;
            console.log(notes);
            allNotes.push(notes);
            temp.remove();
            if (addedCount == [...document.getElementsByClassName("kp-notebook-library-each-book")].length) {
                chrome.storage.local.set({ addNotes: allNotes });
                console.log(allNotes);
                syncToRemNote(allNotes);
            }
        });

    }

    if (new URL(location.href).origin == "https://www.amazon.com") {
        loader.remove();
        canvas.remove();
        fakeAlert("To import your Kindle notes into RemNote, please sign in.\n\nThen, press \"Sync\".", "No Amazon credentials are viewed or stored");
        return
    } else {
        //Delay to allow sidebar to fully load
        setTimeout(loadNotes, 3000);
    }

    async function syncToRemNote(notes) {
        updateStatus("Syncing books");
        var colors = ["Pink", "Orange", "Yellow", "Blue"];
        var kindleFolder = await getByName(
            "Kindle Notes");

        if (kindleFolder.found == false) {
            kindleFolder = await create(
                "Kindle Notes", null, { "isDocument": true });
            kindleFolder = kindleFolder["remId"];
        } else {
            kindleFolder = kindleFolder["_id"];
        }

        for (book of notes) {
            updateStatus(`Syncing books (${notes.indexOf(book) + 1}/${notes.length})`)

            if (book.length > 0) {
                var bookFolder = await getByName(
                    book[0].bookTitle,
                    { parentId: kindleFolder });
                console.log(book, bookFolder, kindleFolder);

                if (!bookFolder.found) {
                    bookFolder = await create(
                        `${book[0].bookTitle}  ##[${book[0].bookTitle.replaceAll(" ", "_")}](https://read.amazon.com?asin=${book[0].asin})`,
                        kindleFolder);
                    bookFolder = bookFolder["remId"];
                } else {
                    bookFolder = bookFolder["_id"];
                }

                for (note of book) {
                    circlesToMake.push(1);

                    var currentNote = await getByName(
                        note.text,
                        { parentId: bookFolder });
                    if (!currentNote.found) {
                        //Note not already in book's document, add it.

                        var savedNote = await create(
                            `${note.text} #[[kindle${note.color}]] #[[${note.page}]]`,
                            bookFolder);

                        // var savedNote = await create(
                        //     `${note.text} #[[${note.page}]]`,
                        //     bookFolder);
                        if (note.note != "") {
                            await create(
                                note.note,
                                savedNote["remId"]);
                        }
                    }
                }
            }
        }
        if (!document.hasFocus()) {
            chrome.runtime.sendMessage({ msg: "syncFinished" });
        }
        updateStatus("Notes synced!");
        location.replace(`${REMNOTE_URL}document/${kindleFolder}`)
    }

    async function getByName(name, parameters) {
        var requestBody = {};
        if (parameters) {
            requestBody = parameters;
            requestBody.name = name;
        } else {
            requestBody.name = name;
        }

        requestBody.userId = userId;

        var rem = await fetch("https://api.remnote.io/api/v0/get_by_name", {
            headers: new Headers({
                'Content-Type': 'application/json',
                "x-auth-token": apiKey
            }),
            method: 'POST',
            body: JSON.stringify(requestBody)
        });
        rem = await rem.json();

        return rem;
    }
    async function getById(id) {
        var requestBody = {};

        requestBody.remId = id;
        requestBody.userId = userId;

        var rem = await fetch("https://api.remnote.io/api/v0/get", {
            headers: new Headers({
                'Content-Type': 'application/json',
                "x-auth-token": apiKey
            }),
            method: 'POST',
            body: JSON.stringify(requestBody)
        });
        rem = await rem.json();

        return rem;
    }
    async function create(text, parent, parameters) {
        var requestBody = {};
        if (parameters) {
            requestBody = parameters;
            requestBody.text = text;
            requestBody.parentId = parent;
        } else {
            requestBody.text = text;
            requestBody.parentId = parent;
        }

        requestBody.userId = userId;

        var rem = await fetch("https://api.remnote.io/api/v0/create", {
            headers: new Headers({
                'Content-Type': 'application/json',
                "x-auth-token": apiKey
            }),
            method: 'POST',
            body: JSON.stringify(requestBody)
        });
        rem = await rem.json();

        return rem;
    }
    function fakeAlert(text) {
        var alertbox = document.createElement("div");
        alertbox.style.all = "unset";
        alertbox.style.backgroundColor = "white";
        alertbox.style.boxShadow = "#8080809e 0px 0px 200px 2000px";
        alertbox.style.borderRadius = "5px";
        alertbox.style.width = "600px";
        alertbox.style.minHeight = "150px";
        alertbox.style.maxHeight = "600px";
        alertbox.style.zIndex = "999";
        alertbox.style.position = "absolute";
        alertbox.style.top = "50%";
        alertbox.style.left = "50%";
        alertbox.style.fontFamily = "roboto,sans-serif"
        alertbox.style.fontWeight = "bold";
        var textdis = document.createElement("span");
        textdis.style.all = "unset";
        textdis.innerText = text;
        textdis.style.fontSize = "15px";
        textdis.style.verticalAlign = "middle";
        textdis.style.display = "inline-block";
        textdis.style.position = "absolute";
        textdis.style.left = "50%";
        textdis.style.top = "calc(50% - 54px)";
        textdis.style.transform = "translateX(-50%)";
        alertbox.appendChild(textdis);
        alertbox.style.padding = "5px";
        alertbox.style.paddingBottom = "35px";
        alertbox.style.transform = "translate(-50%, -100%)";
        alertbox.style.overflow = "scroll";
        alertbox.style.overflowX = "hidden";
        alertbox.style.transition = "transform .2s, opacity .3s";
        alertbox.style.opacity = "0";
        alertbox.style.textAlign = "center";
        var close = document.createElement("div");
        close.style.all = "unset";
        close.style.width = "77px";
        close.style.height = "24px";
        close.style.lineHeight = "24px";
        close.style.fontWeight = "900";
        close.style.fontFamily = "sans-serif";
        close.style.border = "#48C7E2 solid 4px";
        close.style.borderRadius = "5px";
        close.style.bottom = "5px";
        close.style.cursor = "pointer";
        close.style.left = "50%";
        close.style.transform = "translateX(-50%)";
        close.style.zIndex = "5";
        close.innerText = "OK";
        close.style.fontFamily = "sans-serif";
        close.style.color = "#48C7E2";
        close.style.textAlign = "center";
        close.style.position = "fixed";
        close.onclick = function () {
            alertbox.style.opacity = "0";
            alertbox.style.transform = "translate(-50%,-100%)";
            setTimeout(function () {
                alertbox.remove();
                delete alertbox;
                delete close;
            }, 300);
        }
        alertbox.appendChild(close);
        document.body.appendChild(alertbox);
        setTimeout(function () {
            alertbox.style.opacity = "1";
            alertbox.style.transform = "translate(-50%,-50%)";
        }, 1);
    }

}

function updateStatus(text) {
    syncerStatusText.innerText = text;
}
window.onmessage = function (x) {
    if (x.data == "gotCreds") {
        checkCredentials();
    }
    console.log(x);
}