var injectedCode = `window.addEventListener("load", () => {
    window.loadInIFrame();
    var myEvent = new CustomEvent("pageLoaded");
    document.dispatchEvent(myEvent);
    });`;
var script = document.createElement('script');
script.textContent = injectedCode;
(document.body || document.head || document.documentElement).appendChild(script);

document.addEventListener("pageLoaded", function (e) {
    if (!localStorage.getItem("userToken") || !localStorage.getItem("userId")) {
        //Signed out
        parent.postMessage("signedOut", "https://read.amazon.com");
    } else {
        chrome.storage.local.set({ apiKey: localStorage.getItem("userToken") });
        chrome.storage.local.set({ userId: localStorage.getItem("userId") });
        console.log("sendingId");
        parent.postMessage("gotCreds", "https://read.amazon.com");
    }
})
