var injectedCode = `window.addEventListener("load", () => {
    window.loadInIFrame();
    var myEvent = new CustomEvent("pageLoaded");
    document.dispatchEvent(myEvent);
    });`;
var script = document.createElement('script');
script.textContent = injectedCode;
(document.body || document.head || document.documentElement).appendChild(script);

document.addEventListener("pageLoaded", function (e) {
    chrome.storage.local.set({ apiKey: localStorage.getItem("userToken") });
    chrome.storage.local.set({ userId: localStorage.getItem("userId") });

    parent.postMessage("gotCreds", "https://read.amazon.com");
})
