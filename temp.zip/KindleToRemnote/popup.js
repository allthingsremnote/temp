var emailRegex = new RegExp(".+@.+");
var serverBaseUrl = "http://ibooktoremnote.herokuapp.com/"
// serverBaseUrl = "http://localhost:8080/"
var validiBookEmail = false;
var knownDuplicate = false;
var authId;
chrome.storage.local.get(["extensionAuthId"], async function (extensionAuthIdResult) {
    authId = extensionAuthIdResult.extensionAuthId;

    kindleSync.onclick = function () {
        kindleSync.classList.add("clicked");
        this.onclick = function () { }

        setTimeout(function () {
            chrome.runtime.sendMessage({ msg: "sync" }, function (response) {
                console.log(response);
            });
        }, 300);
    }
    ibookSync.onclick = async function () {
        startLoading();
        var existingUser = await fetch(`${serverBaseUrl}checkFromId?id=${authId}`);
        stopLoading();
        existingUser = await existingUser.json();
        if (existingUser.found) {
            ibookAlreadyLinkedPage.style.display = "block";
            ibookSignUpPage.style.display = "none";
            ibookCurrentAccount.innerText = `Connected to ${existingUser.email}`;
            ibookCurrentAccount.title = `Connected to ${existingUser.email}`;
            var hourAmount = Math.round(existingUser.lastSynced);
            lastSynced.innerText = (existingUser.lastSynced ? `Synced ${hourAmount} hour${(hourAmount == 1 ? "" : "s")} ago` : `Never synced`)
        }
        if (existingUser.unlinked) {
            ibookUnlinked.style.display = "block";
            ibookUnlinked.onclick = function () {
                window.open(`${serverBaseUrl}registerUser?id=${authId}`);
            }
        }
        ibookSync.onclick = function () { }
        buttonCont.style.left = "-100vw";
        ibookPopup.style.left = "0vw";
    };
    ibookSwitchAccounts.onclick = function () {
        knownDuplicate = true;
        ibookAlreadyLinkedPage.style.display = "none";
        ibookSignUpPage.style.display = "block";
    }
    ibookEmailInput.oninput = function () {
        if (emailRegex.test(ibookEmailInput.value)) {
            signUpSubmit.style.cursor = "pointer";
            validiBookEmail = true;
        } else {
            signUpSubmit.style.cursor = "not-allowed";
            validiBookEmail = false;
        }
    }
    signUpSubmit.onclick = emailInputted;
    async function emailInputted() {
        if (!validiBookEmail) { return }
        var userWithEmail = await fetch(`${serverBaseUrl}checkUser?email=${ibookEmailInput.value}`);
        userWithEmail = await userWithEmail.json();
        console.log(userWithEmail);
        if (!knownDuplicate && userWithEmail.userExists && userWithEmail.credentials) {
            //A fully set-up account already exists for that email
            signUpText.innerText = "A RemNote account has already been linked to that email.\n\nContinue anyway?";
            ibookEmailInput.style.display = "none";
            signUpSubmit.style.top = "160px";
            iBookBack.style.display = "block";

            signUpSubmit.onclick = sendEmail;
        } else {
            sendEmail();
        }
    }

    function sendEmail() {
        ibookSignUpPage.style.display = "none";
        emailSentPage.style.display = "block";
        fetch(`${serverBaseUrl}sendEmail`, {
            "headers": {
                "content-type": "application/json; charset=utf-8"
            },
            method: "POST",
            body: JSON.stringify({ email: ibookEmailInput.value, id: authId })
        })
    }
    bot.onclick = function () {
        window.open("http://ibooktoremnote.herokuapp.com/instructions");
    }
    ibookInstructions.onclick = function () {
        window.open("http://ibooktoremnote.herokuapp.com/instructions");
    }
    function startLoading() {
        loadCont.style.display = "block";
        setTimeout(function () {
            loadCont.style.opacity = "1";
        }, 0)
    }
    function stopLoading() {
        loadCont.style.opacity = "0";
        setTimeout(function () {
            loadCont.style.display = "none";
        }, 200)
    }
});
setTimeout(function () {
    //Attempt to fix weird Brave bug. CSS/dom was all messed up until page refresh. \/(._.)\/
    if (!location.hash) {
        console.log("Reloading");
        location.replace(`${location.href}#reloaded`);
        location.reload();
    }
}, 10);